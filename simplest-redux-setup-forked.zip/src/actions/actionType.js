export const BUG_ADDED = "bugadded";
export const BUG_REMOVED = "bugremoved";
export const BUG_RESOLVED = "bugresolved";
